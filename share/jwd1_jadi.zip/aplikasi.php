<?php

// memulai session php
SESSION_START();

// cek apakah sudah login jika tidak paksa untuk login
if(!isset($_SESSION["logged"])){
	header("location: index.php");
}

?>

<html>
	<head>
		<title>Aplikasi Sederhana</title>
		<style>
			body{
				background-color: black;
				text-align: center;
			}

			table{
				border-collapse: collapse;
				color: white;
				margin: 10px auto;
				margin-bottom: 0;
			}

			td{
				border: 1px solid white;
				padding: 5px;
				font-family: arial;
			}

			input{
				border: none;
				outline: none;
				background-color: transparent;
				color: white;
			}

			button{
				border: 1px solid white;
				border-radius: 5px;
				background-color: transparent;
				color: white;
				padding: 3px;
			}

			button:hover{
				color: black;
				background-color: red;
			}

			.logout{
				color: rgb(255, 0, 0);
				text-decoration: none;
				border: 1px dotted rgb(255, 0, 0);
				border-radius: 5px;
				padding: 2px;
			}
		</style>
	</head>
	<body>
		<table id="tb">
			<tr>
				<td>Nama</td>
				<td><input type="text" id="inp0" /></td>
			</tr>
			<tr>
				<td>Nama</td>
				<td><input type="text" id="inp1" /></td>
			</tr>
			<tr>
				<td>Nama</td>
				<td><input type="text" id="inp2" /></td>
			</tr>
		</table>
		<table id="output" style="display: none;">
			<tr>
				<td>No</td>
				<td>Nama</td>
			</tr>
		</table>
		<br />
		<button onclick="getData()" id="random">Random</button>
		<button onclick="generate()" id="plus">++ Form</button>

		<br/>
		<br/>

		<a class="logout" href="logout.php">Logout</a>

		<script>
			
			// membuat fungsi untuk create element
			let start = 3;
			const tb = document.getElementById("tb");

			function generate(){
				let form = document.createElement("tr");
				form.innerHTML = "<td>Nama</td><td><input type='text' id='inp"+ start +"'></td>";

				tb.appendChild(form);
				start++;
			}

			// mengambil semua data dan menyimpan ke dalam array
			let nama = [];
			// hasil dari parsing data
			let hasil = [];

			function getData(){
				for(let i = 0; i < start; i++){
					const komponen = document.getElementById("inp" + i).value;

					// filter input pengguna
					if(komponen == ""){
						return alert("Harap isi nama terlebih dahulu");
					}else{
						nama.push(komponen);
					}
				}

				document.getElementById("plus").disabled = true;
				document.getElementById("random").disabled = true;
				angkaAcak();
				// parsing data
				parsingData();
				// show data
				show();
			}

			// membuat index acak
			let indexAcak = [];

			function angkaAcak(){
				if(indexAcak.length == nama.length){
					return;
				}else{
					const x = Math.floor(Math.random() * nama.length);

					if(indexAcak.includes(x)){
						angkaAcak();
					}else{
						indexAcak.push(x);
						angkaAcak();
					}
				}
			}

			// membuat parsing data ke variabel hasil
			function parsingData(){
				for(let i = 0; i < nama.length; i++){
					hasil.push(nama[indexAcak[i]]);
				}
				console.log(hasil);
			}

			// membuat fungsi untuk menampilkan hasil
			function show(){
				const out = document.getElementById("output");

				for(let i = 0; i < hasil.length; i++){
					out.innerHTML += "<tr><td>"+ (i + 1) +"</td><td>"+ hasil[i] +"</td></tr>"
				}

				tb.setAttribute("style", "display: none;");
				out.setAttribute("style", "");
			}


		</script>
	</body>
</html>