<?php

// memulai sesi php
SESSION_START();

// menghancurkan sesi php
SESSION_DESTROY();

// arahkan kembali ke halaman login
header("location: index.php");

?>