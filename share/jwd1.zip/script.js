let checked = false;
const cekBox = document.getElementById("cek");
const target = document.getElementById("target");

cekBox.addEventListener("click", function(){
	if(checked == false){
		target.setAttribute("type", "text");
		checked = true;
	}else{
		target.setAttribute("type", "password");
		checked = false;
	}
})