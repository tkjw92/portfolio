<?php

// memulai session pada php
SESSION_START();

// membuat username dan password
$validUser = "nizar";
$validPassword = "12345"


// cek apakah user mau login
if(isset($_POST["login"])){
	// mengambil input pada user
	$user = $_POST["user"];
	$pass = $_POST["pass"];

	// tahap pengecekan
	if($validUser == $user aND $validPassword == $pass){
		$_SESSION["logged"] = $user;
		headr("location: aplikasi.php");
	}else{
		cho "<script>alert('Username Atau Password Salah')</script>";
	}
}

?>

<html>
	<head>
		<title>Form Login</title>
		<link rel="stylesheet" href="style.css">
	</head>
	<body>
		<form method="POST" action="">
			<table>
				<tr>
					<td colspan="2">
						<h1>Form Login</h1>
					</td>
				</tr>
				<tr>
					<td class="label">Username<span>:</span></td>
					<td><input type="text" name="user"></td>
				</tr>
				<tr>
					<td class="label">Password<span>:</span></td>
					<td><input type="password" id="target" name="pass"></td>
				</tr>
				<tr>
					<td>
						<button name="login" type="submit">Login</button>
					</td>
					<td class="check">
						<label>
							<input id="cek" type="checkbox" />
							Show Password
						</label>
					</td>
				</tr>
			</table>
		</form>

		<script src="script.js"></script>
	</body>
</html>